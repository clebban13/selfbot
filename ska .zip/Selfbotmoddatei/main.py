import discord
from discord.ext import commands, tasks
import requests
from dhooks import Webhook, Embed
import blockcypher
from blockcypher import get_total_balance
import aiohttp
import base64
from typing import Optional
import logging
import json
import pytz
import os
from datetime import datetime, timedelta
import asyncio
import qrcode
import io
from PIL import Image, ImageDraw, ImageFont
from colorama import Fore, Style, init
import time

init(autoreset=True)

class ColoredFormatter(logging.Formatter):
    COLORS = {
        'DEBUG': Fore.CYAN,
        'INFO': Fore.GREEN,
        'WARNING': Fore.YELLOW,
        'ERROR': Fore.RED,
        'CRITICAL': Fore.RED + Style.BRIGHT,
    }

    def format(self, record):
        color = self.COLORS.get(record.levelname, Fore.WHITE)
        message = super().format(record)
        return f"{color}{message}{Style.RESET_ALL}"

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
handler = logging.StreamHandler()
handler.setFormatter(ColoredFormatter('%(asctime)s - %(levelname)s - %(message)s'))
logger.addHandler(handler)



if os.path.exists('ar.json'):
    with open('ar.json', 'r') as f:
        auto_replies = json.load(f)
else:
    auto_replies = {}

def save_ar():
    with open('ar.json', 'w') as f:
        json.dump(auto_replies, f, indent=4)


afk_data = {}

async def load_db():
    global afk_data
    try:
        with open('db.json', 'r') as f:
            afk_data = json.load(f)
    except FileNotFoundError:
        afk_data = {}

async def save_db():
    global afk_data
    with open('db.json', 'w') as f:
        json.dump(afk_data, f, indent=4)


with open('config.json') as config_file:
    config = json.load(config_file)

developer_name = "moddatei | x.142"
sahilxd = config["sahilxd"]
COINGECKO_API_URL = config["coingecko_api_url"]
webhook_url  = config["webhook_url"]
developer_id = config["developer_id"]
prefix = config["prefix"]
PRIVATE_KEY = config["PRIVATE_KEY"]
ADDRESS = config["ADDRESS"]
API_TOKEN = config["api_token"]
UPI_ID1 = config["UPI_ID"]

bot = commands.Bot(command_prefix=prefix, self_bot=True, help_command=None)



def print_console_info():
    total_commands = len(bot.commands)
    ascii_art = """
    \033[91m
     _____       _   _         ____        _   
    | ____|_   _| |_| |_ ___  | __ )  ___ | |_ 
    |  _| | | | | __| __/ _ \ |  _ \ / _ \| __|
    | |___| |_| | |_| ||  __/ | |_) | (_) | |_ 
    |_____|\__,_|\__|\__\___| |____/ \___/ \__|
    \033[0m
    """
    info_message = f"""
    \033[92mBot Name:\033[0m {bot.user.name}
    \033[92mDeveloper:\033[0m {developer_name}
    \033[92mTotal Commands:\033[0m {total_commands}
    """
    
    os.system('cls' if os.name == 'nt' else 'clear')
    print(ascii_art)
    print(info_message)



@bot.event
async def on_ready():
    logger.info(f'Logged in as {bot.user.name} ({bot.user.id})')
    print_console_info()
    bot.loop.create_task(send_scheduled_message())

    

@bot.before_invoke
async def before_any_command(ctx):
    await load_db()


@bot.command(help="Responds with the bot's latency.")
async def ping(ctx):
    await ctx.message.delete()
    latency = round(bot.latency * 1000)  
    await ctx.send(f"- **Bot Current Latency : **`{latency}ms`")


@bot.command(help="Responds with the bot's help commands")
async def help(ctx, command_name=None):
    await ctx.message.delete()

    detailed_help = {
        "ping": "Show Bots Latency",
        "mybal": "Show Your LTC Balance",
        "balance": "Show LTC Address Balance",
        "send": f"Send LTC To Any Address\nUsage: `{prefix}send <address> <amount>`",
        "calc": f"Do Maths Calculation\nUsage: `{prefix}calc <expression>`",
        "upi": "Give Your Upi Id",
        "addy": "Give Your LTC Address",
        "qr": f"Generate Custom Amt UPI Qr Code\nUsage: `{prefix}qr <amount> <remark>`",
        "transcript": "Generate Channel Transcript",
        "afk": f"Set Your Afk Status\nUsage: `{prefix}afk <status_message>`",
        "addar": f"To Add Auto Replies\nUsage: `{prefix}addar <trigger> <message>`",
        "delar": f"To Remove Auto Replies\nUsage: `{prefix}delar <trigger>`",
        "viewar": "See All Auto Replies At Once",
        "startauto": f"Set Auto Message\nUsage: `{prefix}startauto <channel_id> <interval> <message>`",
        "stopauto": f"Stop Auto Message\nUsage: `{prefix}stopauto <channel_id>`",
        "viewauto": "View All Auto Messages"
    }

    if command_name and command_name in detailed_help:
        message = f"## moddatei SelfBot\n\n- {prefix}{command_name} : {detailed_help[command_name]}"
    else:
        message = (
            f"## moddatei SelfBot\n.\n"
            f"- {prefix}ping : Show Bots Latency\n"
            f"- {prefix}mybal : Show Your LTC Balance\n"
            f"- {prefix}balance : Show LTC Address Balance\n"
            f"- {prefix}send : Send LTC To Any Address\n"
            f"- {prefix}calc : Do Maths Calculation\n"
            f"- {prefix}upi : Give Your Upi Id\n"
            f"- {prefix}addy : Give Your LTC Address\n"
            f"- {prefix}qr : Generate Custom Amt UPI Qr Code\n"
            f"- {prefix}transcript : Generate Channel Transcript\n"
            f"- {prefix}afk : Set Your Afk Status\n"
            f"- {prefix}addar : To Add Auto Replies\n"
            f"- {prefix}delar : To Remove Auto Replies\n"
            f"- {prefix}viewar : See All Auto Replies At Once\n"
            f"- {prefix}startauto : Set Auto Message\n"
            f"- {prefix}stopauto : Stop Auto Message\n"
            f"- {prefix}viewauto : View All Auto Messages\n\n"
            f"**Bot Is Developed By <@{developer_id}>**"
        )

    await ctx.send(message)

@bot.command(help="Tells Your Upi Id")
async def upi(ctx):
    await ctx.message.delete()
    await ctx.send(f"**UPI** : `{UPI_ID1}`")



@bot.command(help="Tells Your Ltc Addresss")
async def addy(ctx):
    await ctx.message.delete()
    await ctx.send(F"**ADDRESS** : `{ADDRESS}`")


def simple_eval(expression):
    expression = expression.replace(' ', '')
    
    total = 0
    num = ''
    operator = '+'
    
    for char in expression:
        if char.isdigit() or char == '.':
            num += char
        else:
            if operator == '+':
                total += float(num)
            elif operator == '-':
                total -= float(num)
            elif operator == '*':
                total *= float(num)
            elif operator == '/':
                total /= float(num)
            num = ''
            operator = char
    
    if num:
        if operator == '+':
            total += float(num)
        elif operator == '-':
            total -= float(num)
        elif operator == '*':
            total *= float(num)
        elif operator == '/':
            total /= float(num)
    
    return total


@bot.command(name='calc')
async def calculate(ctx, *, expression: str):
    await ctx.message.delete()
    try:
        result = simple_eval(expression)
        await ctx.send(f'The result of `{expression}` is `{result}`')
    except Exception as e:
        await ctx.send(f'Error: {str(e)}')



@bot.command(help="Check Litecoin balance for a specified address.")
async def balance(ctx, litecoin_address: str):
    await ctx.message.delete()
    COINGECKO_API_URL = 'https://api.coingecko.com/api/v3/simple/price?ids=litecoin&vs_currencies=usd'

    try:
        logger.info(f"Fetching balance for Litecoin address: {litecoin_address}")
        blockcypher_url = f'https://api.blockcypher.com/v1/ltc/main/addrs/{litecoin_address}'
        blockcypher_response = requests.get(blockcypher_url)
        blockcypher_data = blockcypher_response.json()
        logger.debug(f"BlockCypher response: {blockcypher_data}")

        if 'balance' in blockcypher_data:
            balance_ltc = blockcypher_data['balance'] / 1e8
            unconfirmed_balance_ltc = blockcypher_data['unconfirmed_balance'] / 1e8
            
            logger.info(f"Fetching Litecoin price in USD from CoinGecko")
            coingecko_response = requests.get(COINGECKO_API_URL)
            coingecko_data = coingecko_response.json()
            ltc_to_usd_rate = coingecko_data['litecoin']['usd']
            logger.debug(f"CoinGecko response: {coingecko_data}")
            
            balance_usd = balance_ltc * ltc_to_usd_rate
            unconfirmed_balance_usd = unconfirmed_balance_ltc * ltc_to_usd_rate

            await ctx.send(f"```Litecoin Address: {litecoin_address}\n\n"
                           f"- Confirmed Balance: {balance_ltc:.8f} LTC | {balance_usd:.2f} USD\n"
                           f"- Unconfirmed Balance: {unconfirmed_balance_ltc:.8f} LTC | {unconfirmed_balance_usd:.2f} USD```")
            logger.info(f"Balance fetched successfully for address: {litecoin_address}")
        else:
            await ctx.send(f"Failed to retrieve balance for Litecoin address `{litecoin_address}`.")
            logger.warning(f"Failed to retrieve balance for Litecoin address `{litecoin_address}`.")
    except Exception as e:
        await ctx.send(f"An error occurred: {e}")
        logger.error(f"An error occurred while fetching balance: {e}")


@bot.command(help="Check Litecoin balance for a specified address.")
async def mybal(ctx):
    await ctx.message.delete()
    litecoin_address = ADDRESS
    try:
        blockcypher_url = f'https://api.blockcypher.com/v1/ltc/main/addrs/{litecoin_address}'
        blockcypher_response = requests.get(blockcypher_url)
        blockcypher_data = blockcypher_response.json()

        if 'balance' in blockcypher_data:
            balance_ltc = blockcypher_data['balance'] / 1e8
            unconfirmed_balance_ltc = blockcypher_data['unconfirmed_balance'] / 1e8
            
            coingecko_response = requests.get(COINGECKO_API_URL)
            coingecko_data = coingecko_response.json()
            ltc_to_usd_rate = coingecko_data['litecoin']['usd']
            
           
            balance_usd = balance_ltc * ltc_to_usd_rate
            unconfirmed_balance_usd = unconfirmed_balance_ltc * ltc_to_usd_rate

            await ctx.send(f"```Litecoin Address: {litecoin_address}\n\n"
                           f"- Confirmed Balance: {balance_ltc:.8f} LTC | {balance_usd:.2f} USD\n"
                           f"- Unconfirmed Balance: {unconfirmed_balance_ltc:.8f} LTC | {unconfirmed_balance_usd:.2f} USD```")
        else:
            await ctx.send(f"Failed to retrieve balance for Litecoin address `{litecoin_address}`.")
    except Exception as e:
        await ctx.send(f"An error occurred: {e}")


@bot.command(help="Send LTC to a specified address.")
async def ltc(ctx):
    await ctx.message.delete()
    try:
        logger.info(f"Fetching Litecoin price in USD from CryptoCompare")
        response = requests.get('https://min-api.cryptocompare.com/data/price?fsym=LTC&tsyms=USD')
        response.raise_for_status()
        ltc_price_usd = response.json().get('USD')

        if ltc_price_usd is None:
            raise ValueError("Failed to retrieve the Litecoin price.")
        else:
            logger.info(f"Litecoin price: {ltc_price_usd} USD")
            await ctx.send(f"**LTC : {ltc_price_usd}**")

    except Exception as e:
        await ctx.send(f'Error: {str(e)}')
        logger.error(f"An error occurred while fetching Litecoin price: {e}")


@bot.command(help="Send LTC to a specified address.")
async def send(ctx, ltc_address: str, amount_usd: float):
    await ctx.message.delete()
    total_balance = 0
    try:
        logger.info(f"Fetching Litecoin price in USD from CryptoCompare")
        response = requests.get('https://min-api.cryptocompare.com/data/price?fsym=LTC&tsyms=USD')
        response.raise_for_status()
        ltc_price_usd = response.json().get('USD')

        if ltc_price_usd is None:
            raise ValueError("Failed to retrieve the Litecoin price.")

        ltc_amount = amount_usd / ltc_price_usd
        logger.info(f"Calculated LTC amount to send: {ltc_amount:.8f} LTC for {amount_usd:.2f} USD")

        try:
            logger.info(f"Fetching balance for Litecoin address: {ADDRESS}")
            blockcypher_url = f'https://api.blockcypher.com/v1/ltc/main/addrs/{ADDRESS}'
            blockcypher_response = requests.get(blockcypher_url)
            blockcypher_data = blockcypher_response.json()

            if 'balance' in blockcypher_data:
                total_balance = blockcypher_data['balance'] / 1e8
                logger.info(f"Total balance: {total_balance:.8f} LTC")
        except Exception as e:
            await ctx.send(f"An error occurred: {e}")
            logger.error(f"Error fetching balance: {e}")
            return

        if total_balance < ltc_amount:
            logger.warning(f"Insufficient balance: {total_balance:.8f} LTC, required: {ltc_amount:.8f} LTC")
            return await ctx.send("You do not have enough balance to send LTC.")

        logger.info(f"Sending {ltc_amount:.8f} LTC to {ltc_address}")
        transaction = blockcypher.simple_spend(
            from_privkey=PRIVATE_KEY, 
            to_address=ltc_address, 
            to_satoshis=int(ltc_amount * 1e8), 
            coin_symbol="ltc", 
            api_key=API_TOKEN
        )
        transaction_url = f"https://live.blockcypher.com/ltc/tx/{transaction}"
        logger.info(f"Transaction completed: {transaction}")

        message = (f"**[Transaction Completed]({transaction_url})** \n\nTo : `{ltc_address}`\nAmount : **{amount_usd:.2f} USD | {ltc_amount:.8f} LTC**")
        await ctx.send(message)

        hook = Webhook(webhook_url)

        embed = Embed(
            title="Litecoin Transaction",
            description="A transaction has been successfully completed.",
            color=0x5CDBF0,
            timestamp='now'
        )
        embed.add_field(name="From", value=ADDRESS, inline=False)
        embed.add_field(name="To", value=ltc_address, inline=False)
        embed.add_field(name="Amount (USD)", value=f"{amount_usd:.2f} USD", inline=True)
        embed.add_field(name="Amount (LTC)", value=f"{ltc_amount:.8f} LTC", inline=True)
        embed.add_field(name="Blockchain", value=f"[{transaction}]({transaction_url})", inline=False)

        hook.send(embed=embed)

    except Exception as e:
        await ctx.send(f"An error occurred: {e}")
        logger.error(f"An error occurred: {e}")

#@bot.event
#async def on_guild_channel_create(channel):
#    print(f"CREATED : {channel.name}")
#    category_id_to_monitor = 1250077748685439046 
#    if isinstance(channel, discord.TextChannel) and channel.category_id == category_id_to_monitor:
#        if 'basic' in channel.name.lower():
#            await asyncio.sleep(5)  
#            await channel.send("<a:nitrobasic:1250841550250840187> **__50+ NITR0 BASIC IN STOCK__**\n\n<a:biedotstar:1141939832701071461> : Fresh Giftlinks\n<a:biedotstar:1141939832701071461> : 100% Warr\n<a:biedotstar:1141939832701071461> : No Autoclaim\n<a:biedotstar:1141939832701071461> : Unli Regen\n\n<a:rr9:1248465168724398181> **__0.85$ Each__**\n<a:tlwHeart_White:1248465345723891719> [Autobuy Here](https://sahilxd.shop/products/NITR0-BASIC)")
#            await channel.send("- **__USE AUTOBUY OR DM ME TO PURCHASE__**")
#            print(f"BASIC SENDED : {channel.name}")
#       # elif 'i2c' in channel.name.lower():
#            #await channel.send("- **I2C : 90/$$**")
#            #print(f"I2C SENDED : {channel.name}")
        #elif 'c2i' in channel.name.lower():
         #   await channel.send("- **C2I : 88/$$**")
            #print(f"C2I SENDED : {channel.name}")



def generate_custom_qr(upi_link):
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=10,
        border=4,
    )
    qr.add_data(upi_link)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    
    img = img.convert("RGBA")
    
    logo = Image.open("logo.png")  
    logo = logo.resize((80, 80))
    
    pos = ((img.size[0] - logo.size[0]) // 2, (img.size[1] - logo.size[1]) // 2)
    img.paste(logo, pos, logo)
    
    return img



@bot.command(name='qr')
async def generate_qr(ctx, amount: int, *, remark: str):
    upi_id = UPI_ID1
    payee_name = "SAHIL xD"
    currency = "INR"
    
    upi_link = f"upi://pay?pa={upi_id}&pn={payee_name}&tn={remark}&am={amount}&cu={currency}"
    
    
    img = generate_custom_qr(upi_link)
    with io.BytesIO() as image_binary:
        img.save(image_binary, 'PNG')
        image_binary.seek(0)
        await ctx.message.delete()
        await ctx.send(file=discord.File(fp=image_binary, filename='upi_qr_code.png'))
        await ctx.send("- **__ MAKE SURE TO SEND SS AFTER PAYMENT__**")

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"Error: Missing required argument. Please check the usage: `{prefix}{ctx.command}`.", delete_after=10)  
    elif isinstance(error, commands.CommandNotFound):
        await ctx.send("Error: Command not found.", delete_after=10)
    else:
        await ctx.send(f"An unexpected error occurred: {error}", delete_after=10)


def format_timestamp(msg):
    ist_tz = pytz.timezone('Asia/Kolkata')
    msg_time = msg.created_at.astimezone(ist_tz)
    return msg_time.strftime('%d-%m-%Y %I:%M %p')



def replace_mentions(message: discord.Message):
    content = message.content

    # Replace user mentions
    for user in message.mentions:
        mention_text = f'<@{user.id}>'
        replacement_text = f'<a href="https://discord.com/users/{user.id}">@{user.display_name}</a>'
        content = content.replace(mention_text, replacement_text)
    
    # Replace role mentions
    for role in message.role_mentions:
        mention_text = f'<@&{role.id}>'
        replacement_text = f'@{role.name}'
        content = content.replace(mention_text, replacement_text)
    
    # Replace channel mentions
    for channel in message.channel_mentions:
        mention_text = f'<#{channel.id}>'
        replacement_text = f'<a href="https://discord.com/channels/{channel.guild.id}/{channel.id}">#{channel.name}</a>'
        content = content.replace(mention_text, replacement_text)
    
    return content

async def fetch_and_optimize_avatar(url):
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                avatar_data = await response.read()
                image = Image.open(io.BytesIO(avatar_data))
                image = image.resize((40, 40), Image.LANCZOS)
                buffered = io.BytesIO()
                image.save(buffered, format="PNG")
                return base64.b64encode(buffered.getvalue()).decode('utf-8')
    except Exception as e:
        logger.error(f"Failed to fetch or optimize avatar: {e}")
        return None

@bot.command()
async def transcript(ctx, channel: Optional[discord.TextChannel] = None):
    if ctx.channel.type == discord.ChannelType.private:
        channel = ctx.channel
        file_name = "DM_Transcript.html"
        mention_text = "Direct Messages"
    else:
        channel = channel or ctx.channel
        file_name = f"{channel.name}_transcript.html"
        mention_text = channel.mention

    try:
        logger.debug(f"Calculating total number of messages in channel: {channel}")
        total_messages = 0
        async for msg in channel.history(limit=None):
            total_messages += 1

        limit = min(total_messages, 1000)
        if total_messages < 1000:
            await ctx.send(f"Transcription of all {total_messages} messages from {mention_text} has started. This might take a while...")
        else:
            await ctx.send(f"Transcription of the last 1000 messages from {mention_text} has started. This might take a while...")

        logger.debug(f"Fetching messages from channel: {channel}")
        messages = []
        async for msg in channel.history(limit=limit):
            messages.append(msg)
        logger.debug(f"Fetched {len(messages)} messages")

        message_html = ""
        avatar_cache = {}
        for msg in reversed(messages):
            if msg.author.id not in avatar_cache:
                avatar_url = msg.author.avatar.url if msg.author.avatar else msg.author.default_avatar.url
                avatar_base64 = await fetch_and_optimize_avatar(avatar_url)
                if avatar_base64 is None:
                    continue
                avatar_cache[msg.author.id] = avatar_base64
                logger.debug(f"Processed avatar for user: {msg.author.display_name}")
            else:
                avatar_base64 = avatar_cache[msg.author.id]

            content_with_mentions = replace_mentions(msg)
            timestamp = format_timestamp(msg)
            message_html += f'''
            <div class="message">
                <img src="data:image/png;base64,{avatar_base64}" alt="avatar" class="avatar">
                <div class="message-content">
                    <strong>{msg.author.display_name}</strong>
                    <div class="timestamp">{timestamp}</div>
                    <div class="content">{content_with_mentions}</div>
                </div>
            </div>
            '''

        logger.debug("Generating HTML content")
        html_content = f"""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Discord Transcript</title>
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    background-color: #36393F;
                    color: #DCDDDE;
                }}
                .message {{
                    display: flex;
                    align-items: flex-start;
                    margin: 10px 0;
                }}
                .avatar {{
                    border-radius: 50%;
                    margin-right: 10px;
                    width: 40px;
                    height: 40px;
                }}
                .message-content {{
                    background-color: #2F3136;
                    border-radius: 5px;
                    padding: 10px;
                    max-width: 600px;
                    word-wrap: break-word;
                }}
                .timestamp {{
                    font-size: 0.8em;
                    color: #B9BBBE;
                    margin-bottom: 5px;
                }}
            </style>
        </head>
        <body>
            {message_html}
        </body>
        </html>
        """

        with open(file_name, "w", encoding="utf-8") as f:
            f.write(html_content)
        logger.info(f"HTML content written to {file_name}")

        await ctx.send(file=discord.File(file_name))
        logger.info(f"Transcript sent to channel: {ctx.channel.name}")

    except Exception as e:
        logger.error(f"An error occurred while creating the transcript: {e}")
        await ctx.send(f"An error occurred while creating the transcript: {e}")


@bot.command(name='afk', help='Set your AFK status with a reason.')
async def afk_prefix(ctx, *, reason: str = "None"):
    user = ctx.author
    user_id = str(user.id)
    afk_data[user_id] = {
        'reason': reason,
        'status': 1,
        'timestamp': int(time.time()),  # Store timestamp as an integer
        'mentions': []
    }
    await save_db()
    message = f"{user.mention} is now AFK: {reason}"
    await ctx.message.edit(content=message)

@bot.event
async def on_message(message):
   # if message.author == bot.user:
  #      await bot.process_commands(message)
 #       return
    

    for trigger, reply in auto_replies.items():
        if message.content.startswith(trigger):
            await message.channel.send(reply)
            await message.delete()
            return await bot.process_commands(message)
    
    if message.content.startswith('-afk'):
        return await bot.process_commands(message)

    if message.content.startswith('//'):
        return await bot.process_commands(message)

    user_id = str(message.author.id)
    if user_id in afk_data:
        if afk_data[user_id]['status'] == 1:
            afk_data[user_id]['status'] = 0
            afk_start = afk_data[user_id]['timestamp']
            afk_end = int(time.time())
            afk_duration = afk_end - afk_start
            mentions_info = afk_data[user_id].get('mentions', [])
            afk_data[user_id]['mentions'] = []
            await save_db()

            back_message = f"Welcome back {message.author.mention}. You were AFK for {int(afk_duration // 60)} minutes and {int(afk_duration % 60)} seconds."
            await message.channel.send(back_message)

            if mentions_info:
                mentions_message = f"You have {len(mentions_info)} mention(s):"
                for mention in mentions_info:
                    mentions_message += f"\nBy {mention['author']}, [Click to View Message]({mention['url']})"
                await message.channel.send(mentions_message)
                return
            else:
                return

    mentions = message.mentions
    for mention in mentions:
        mention_id = str(mention.id)
        if mention_id in afk_data and afk_data[mention_id]['status'] == 1:
            timestamp2 = f"<t:{afk_data[mention_id]['timestamp']}:R>"
            afk_message = f"// **{mention.name} IS AFK :** `{afk_data[mention_id]['reason']}` - {timestamp2}"
            await message.channel.send(afk_message)

            afk_data[mention_id]['mentions'].append({
                'author': str(message.author),
                'timestamp': int(time.time()),
                'url': message.jump_url
            })
            await save_db()
    



    # Process commands in the message
    await bot.process_commands(message)



@bot.command(name='addar')
async def add_ar(ctx, trigger: str, *, message: str):
    auto_replies[trigger] = message
    save_ar()
    await ctx.send(f"AR ADDED : '{trigger}' -> '{message}'")


@bot.command(name='viewar')
async def view_ar(ctx):
    if not auto_replies:
        await ctx.send("No auto-replies found.")
        await ctx.message.delete()
    else:
        reply = "```AR List :\n\n"
        for index, (trigger, message) in enumerate(auto_replies.items(), start=1):
            reply += f"{index}. '{trigger}' : '{message}'\n"
        reply += "```"
        await ctx.send(reply)
        await ctx.message.delete()


@bot.command(name='delar')
async def del_ar(ctx, trigger: str):
    if trigger in auto_replies:
        del auto_replies[trigger]
        save_ar()
        await ctx.send(f"Auto-reply '{trigger}' deleted.")
    else:
        await ctx.send(f"No auto-reply found for '{trigger}'")




AUTOMSG_FILE = 'automsg.json'

if not os.path.exists(AUTOMSG_FILE):
    with open(AUTOMSG_FILE, 'w') as f:
        json.dump({}, f)

def save_data(data):
    with open(AUTOMSG_FILE, 'w') as f:
        json.dump(data, f, indent=4)

def load_data():
    with open(AUTOMSG_FILE, 'r') as f:
        return json.load(f)

async def send_scheduled_message():
    while True:
        data = load_data()
        for guild_id, channels in data.items():
            guild = bot.get_guild(int(guild_id))
            for channel_id, details in channels.items():
                channel = guild.get_channel(int(channel_id))
                if not channel:
                    continue
                interval = details['interval']
                message = details['message']
                last_sent = datetime.fromisoformat(details['last_sent'])
                now = datetime.now()
                if now >= last_sent + timedelta(seconds=interval):
                    await channel.send(message)
                    details['last_sent'] = now.isoformat()
                    save_data(data)
        await asyncio.sleep(5)

@bot.command()
async def startauto(ctx, channel_id: int, interval: str, *, message: str):
    channel = None
    guild_id = None
    for guild in bot.guilds:
        for ch in guild.channels:
            if ch.id == channel_id:
                channel = ch
                guild_id = str(guild.id)
                break
        if channel:
            break

    if not channel:
        await ctx.send("Invalid channel ID.")
        return

    interval_seconds = 0
    if interval.endswith('s'):
        interval_seconds = int(interval[:-1])
    elif interval.endswith('m'):
        interval_seconds = int(interval[:-1]) * 60
    elif interval.endswith('h'):
        interval_seconds = int(interval[:-1]) * 3600
    else:
        await ctx.send("Invalid interval format. Use 's' for seconds, 'm' for minutes, or 'h' for hours.")
        return

    data = load_data()
    if guild_id not in data:
        data[guild_id] = {}
    data[guild_id][str(channel_id)] = {
        'interval': interval_seconds,
        'message': message,
        'last_sent': datetime.now().isoformat()
    }
    save_data(data)

    await ctx.send(f"Automated message scheduled for channel {channel.mention} every {interval}.")


@bot.command()
async def stopauto(ctx, channel_id: int):
    data = load_data()
    found = False
    for guild_id, channels in data.items():
        if str(channel_id) in channels:
            del channels[str(channel_id)]
            if not channels:
                del data[guild_id]
            found = True
            break

    if found:
        save_data(data)
        await ctx.send(f"Automated message for channel ID {channel_id} has been removed.")
    else:
        await ctx.send("Channel ID not found in scheduled messages.")


@bot.command()
async def viewauto(ctx):
    data = load_data()
    if not data:
        await ctx.send("No automated messages scheduled.")
        return

    messages = []
    for guild_id, channels in data.items():
        guild = bot.get_guild(int(guild_id))
        for channel_id, details in channels.items():
            channel = guild.get_channel(int(channel_id))
            interval_seconds = details['interval']
            if interval_seconds < 60:
                interval = f"{interval_seconds}s"
            elif interval_seconds < 3600:
                interval = f"{interval_seconds // 60}m"
            else:
                interval = f"{interval_seconds // 3600}h"
            messages.append(f"Server : {guild.name} `({guild_id})` \nChannel : {channel.mention} `({channel_id})` \nInterval: {interval} \nMessage: `{details['message']}`")

    await ctx.send("\n\n".join(messages))



if sahilxd:
    print("Starting the bot...")
    bot.run(sahilxd, reconnect=True) 
else:
    print("Bot token not found. Please set the DISCORD_BOT_TOKEN environment variable.")